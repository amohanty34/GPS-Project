clc;clear;close all;
times= [314680.806 315000 315300];
%satellite data
[nums,~,raw]= xlsread('sat_data.xlsx');
ind1= 2:82;
ind2= 84:164;
ind3= 166:246;

%pseudo range data
[nm,~,r]= xlsread('prange_data.xlsx');

%first segment
%satellite data
svt= nums(ind1,1);
gt= raw(ind1,1);
%prange data
g= r(:,11);g(1)=[];
sv= nm(:,end);
times= nm(:,2);
prange= nm(:,8);
vel= nm(:,7);

%delete all sbas columns
ind= strcmp(g,'SBAS');
g= g(~ind);
sv= sv(~ind);
times= times(~ind);
prange= prange(~ind);
vel= vel(~ind);

%find the delimiters for bounds;
d1= find(times== 314800.006); d1= d1(1);
d2= find(times== 315150.006); d2= d2(1);

vec_ind=1:d1;
for i=1:d1
    type= g(i);
    sno= sv(i);
    const_name= type{:};
    if strcmpi(const_name, 'GPS')
        A= strcmp(gt,'G');
    elseif strcmpi(const_name,'Galileo')
        A= strcmp(gt,'E');
    elseif strcmpi(const_name,'Glonass')
        A= strcmp(gt,'R');
    end
    A= vec_ind(A);
    B= find(svt==sno);
    ind= intersect(A,B);
    if isempty(ind)
        X1(i)=0;
        Y(i)=0;
        Z(i)=0;
    else
        X1(i)= nums(ind+1,2);
        Y1(i)= nums(ind+1,3);
        Z1(i)= nums(ind+1,4);    
    end
end

%second and third segment do later
header= [{'Time'} {'Type'} {'No'} {'X'} {'Y'} {'Z'} {'Prange'} {'Vel'}];
data= [num2cell(times(1:d1)) g(1:d1) num2cell(sv(1:d1)) num2cell(X1') num2cell(Y1') num2cell(Z1')...
    num2cell(prange(1:d1)) num2cell(vel(1:d1))];
arr= [header;data];
fname= 'final_ranges.xlsx';
xlswrite(fname, arr);







