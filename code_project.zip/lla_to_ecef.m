function [x,y,z]= lla_to_ecef(lat,long,elev)

% input in radians
%output in metres

a= 6378.137* 1000; % in m
b= 6356.752* 1000; % in m
e= sqrt(1- (b./a).^2);
n_phi= a./ sqrt(1- (e.^2).* (sin(lat)).^2);
x= (n_phi + elev).* cos(lat).* cos(long);
y= (n_phi + elev).* cos(lat).* sin(long);
z= (((b./a).^2).* n_phi + elev).* sin(lat);
end