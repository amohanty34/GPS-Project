function xt= imu_forward(xtt, v,a,dt)
xt= xtt+ v.*dt+ 0.5.*a.*dt.^2;
end