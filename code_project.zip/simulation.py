import numpy as np
import math

dt=0.001

class Tobj(object):
    def __init__(self, s, p):
        self.state = s

        self.sats = p

        self.t = 0
    
    def grng(self):
        vr = np.array([self.state[0],self.state[1], 0])
        ranges = []
        
        for sat in self.sats:
            vs = np.array([sat[0],sat[1], sat[2]])
        
            ranges.append(np.linalg.norm(vr - vs) + np.random.normal(0,1))

        return np.array(ranges)

    def godom(self):
        return self.state[2] + np.random.normal(0,.5), self.state[3] + np.random.normal(0,.5)
    
    def upd(self):
        self.t += 1

        if(self.t<1000):
            self.state[2] = 1
            self.state[3] = 0
        elif(self.t<1300):
            self.state[2] = 0
            self.state[3] = -1
        # elif(self.t<1000):
        #     self.state[2] = -1
        #     self.state[3] = 0
        # elif(self.t<1300):
        #     self.state[2] = 0
        #     self.state[3] = 1
        
        self.state[0] += self.state[2]*dt
        self.state[1] += self.state[3]*dt

    def pstate(self):
        print(self.state)
