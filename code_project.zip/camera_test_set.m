clear;clc;close all;
[nums,~,raw]= xlsread('camera_data_trunc.xlsx');
raw(1,:)=[];

%test data, 
g=[]; n=[]; 
%currently taking 5th anf 6th image as test image
for i=5:6: length(raw(:,1))
    gv=[raw(i,5) raw(i+1,5)];
    g= [g gv];
    nv= [raw(i,1) raw(i+1,1)];
    n=[n nv];    
end
h= [{'GPStime'} {'Name'}];
arr=[h;g' n'];
fname= 'camera_test.xlsx';
xlswrite(fname, arr);

%training data, remove the same indices
raw(5:6:end,:)=[];
raw(5:5:end,:)=[];
header=[{'Name'} {'X'} {'Y'} {'Z'} {'GPStime'}];
arr=[header;raw];
fname= 'camera_train.xlsx';
xlswrite(fname, arr);




