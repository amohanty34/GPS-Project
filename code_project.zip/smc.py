########################################################################
# Particle Metropolis-Hastings using gradient and Hessian information
# Copyright (c) 2014 Johan Dahlin ( johan.dahlin (at) liu.se )
#
# smc.py
# Sequential Monte Carlo samplers
#
########################################################################

import logging
import new_helpers as nhp
import seaborn as sns
import _thread
import numpy as np
import pandas as pd
from helpers import *
import matplotlib.pyplot as plt
import matplotlib
import itertools
from scipy import stats
from IPython import display
import math
pi = math.pi
sns.set(color_codes=True)

class smcSampler(object):

    #############################################################################################################################
    # Initalisation
    #############################################################################################################################
    score = []
    infom = []
    xhatf = []
    xhatp = []
    xhats = []
    ll = []
    w = []
    a = []
    p = []
    v = []
    infom1 = []
    infom2 = []
    infom3 = []
    integ = []
    klinteg = []
    error = []

    #############################################################################################################################
    # Default settings
    #############################################################################################################################
    
    #maybe change the following part
    nPart = 95 #num prange meas * T, 95
    Po = 0
    xo =  np.array([4051761.737, 617191.1274, 4870822])
    so = np.array([0, 0,0])
    fixedLag = 5
    resampFactor = 0.66
    onlydiagInfo = 1
    makeInfoPSD = 0
    #mode = "pf"
    mode= "praim"
    resamplingType = "residual"
    filterType = "bootstrap"
    smootherType = "filtersmoother"
    plot_particles = False
    cmap = matplotlib.cm.get_cmap('viridis')

    #############################################################################################################################
    # Particle filtering: bootstrap particle filter
    #############################################################################################################################
    def bPF(self, data, sys, par, fig):
        a = np.zeros((self.nPart, sys.T))
        s = np.zeros((self.nPart, 3, sys.T))
        p = np.zeros((self.nPart, 3, sys.T))
        p_aux = np.zeros((self.nPart, 3, int(sys.par[5])))
        w = np.zeros((self.nPart, sys.T))
        w_b = np.zeros((self.nPart, int(sys.par[5])))
        xh = np.zeros((sys.T, 3))
        xh_b = np.zeros((sys.T, 3))
        sh = np.zeros((sys.T, 3))
        llp = 0.0
        clist = []
        klist = []
        elist = []
        integ_step = 0
        p[:, :, 0] = self.xo
        s[:, :, 0] = self.so

        excel_file= 'final_ranges2.xlsx'
        df = pd.read_excel(excel_file, usecols="A:G")
        gpst= df['Time']

        for tt in range(0, sys.T):
            print ('tt', tt)
            if self.mode == "praim":
                integ_step = tt % sys.par[7] == 1 and tt > sys.par[7]

            if tt != 0:
                # Resample (if needed by ESS criteria)
                if ((np.sum(w[:, tt-1]**2))**(-1) < (self.nPart * self.resampFactor)):
                    nIdx = self.resampleResidual(w[:, tt-1], par)
                    nIdx = np.transpose(nIdx.astype(int))
                else:
                    nIdx = np.arange(0, self.nPart)

                # Propagate
                s[:, :, tt] = sys.h(
                    p[nIdx, :, tt-1], data.u[tt-1], s[nIdx, :, tt-1], tt-1)

                #debug this line below
                p[:, :, tt] = sys.f(p[nIdx, :, tt-1], data.u[tt-1], s[:, :, tt], data.y[tt-1], tt-1) + \
                    np.random.randn(self.nPart, 3) @ sys.fn(
                        p[nIdx, :, tt-1], s[:, :, tt], data.y[tt-1], tt-1)                

                if integ_step:
                    #change the upper limit of normal distribution
                    aux_u = data.u[tt-1] + np.random.normal(0,0.01,size=(int(sys.par[5]), 3))
                    for aux_i in range(int(sys.par[5])):
                        p_aux[:, :, aux_i] = sys.f(p[nIdx, :, tt-1], aux_u[aux_i], s[:, :, tt], data.y[tt-1], tt-1) + np.random.randn(
                            self.nPart, 3) @ sys.fn(p[nIdx, :, tt-1], s[:, :, tt], data.y[tt-1], tt-1)
                a[:, tt] = nIdx

            # Calculate weights
            if self.mode == "praim":
                logwt = logfnormpdf(data.y[tt], 
                    sys.g(
                    p[:, :, tt], data.u[tt], s[:, :, tt], tt), sys.gn(p[:, :, tt], s[:, :, tt], tt)) 
                ind= tt * sys.num_gnss
                logcwt= nhp.kld_metric (logwt, p[:, :, tt], gpst[ind],95, sys.num_cam,tt)
                logwt= logwt + logcwt               
            
            elif self.mode == "pf":
                k= sys.g(
                    p[:, :, tt], data.u[tt], s[:, :, tt], tt)
                logwt = lognormpdf_RAIM(data.y[tt], sys.g(
                    p[:, :, tt], data.u[tt], s[:, :, tt], tt), sys.gn(p[:, :, tt], s[:, :, tt], tt))

            wmax = np.max(logwt)
            w[:, tt] = np.exp(sys.par[6]*(logwt - wmax)) #this factor may change 


            # Calculate RAIM weights
            if self.mode == "praim":
                logwt = logRAIMwt(w[:,tt], logwt, 5)
                wmax    = np.max(logwt);
                w[:,tt] = np.exp(sys.par[6]*(logwt - wmax));              
 
            # Calculate auxiliary weights
            if integ_step:
                for aux_i in range(int(sys.par[5])):
                    logwt2 = logfnormpdf(data.y[tt], sys.g(p_aux[:, :, aux_i], data.u[tt], s[:, :, tt], tt), sys.gn(
                        p_aux[:, :, aux_i], s[:, :, tt], tt))
                    ind= tt * sys.num_gnss
                    logcwt2 = nhp.kld_metric (logwt, p[:, :, tt], gpst[ind],95, sys.num_cam,tt)
                    logwt2 = logwt2 + logcwt2                                       
                    w2max = np.max(logwt2)
                    w_b[:, aux_i] = np.exp(sys.par[6]*(logwt2 - w2max))
                    logwt2 = logRAIMwt(w_b[:,aux_i], logwt2, 5)                    
                    w2max    = np.max(logwt2);
                    w_b[:,aux_i] = np.exp(sys.par[6]*(logwt2 - w2max));

            # Estimate log-likelihood
            log_term = np.log(np.sum(w[:, tt])) - np.log(self.nPart)            
            llp += wmax + log_term
           

            # Estimate state
            w[:, tt] /= np.sum(w[:, tt])
            xh[tt] = np.average(p[:, :, tt], weights=w[:, tt], axis=0)
            sh[tt] = np.average(s[:, :, tt], weights=w[:, tt], axis=0)

            # KDE Integrity
            if integ_step:
                kout, cf, kf, gte = self.kdecomp(
                    sys, w[:, tt], w_b, p_aux, p[:, :, tt], tt, np.ones_like(w[:, tt]), p[:, :, tt], data)
                clist.append(cf)
                klist.append(kf)
                elist.append(gte)

        self.xhatf = xh
        self.shatf = sh
        self.ll = llp
        self.w = w
        self.a = a
        self.p = p
        self.s = s
        self.integ = clist
        self.klinteg = klist
        self.error = elist

    #############################################################################################################################

    def plotTrajectories(self, sys):
        plt.plot(self.p[:, 0, sys.T-1], self.p[:, 1, sys.T-1], 'r.')
        ii = np.argmax(self.w[:, sys.T-1])
        att = ii
        for tt in np.arange(sys.T-2, 0, -1):
            at = self.a[att, tt+1]
            at = at.astype(int)
            plt.plot((self.p[at, 0, tt], self.p[att, 0, tt+1]),
                     (self.p[at, 1, tt], self.p[att, 1, tt+1]), 'k')
            att = at
            att = att.astype(int)

    #############################################################################################################################
    # Resampling helpers
    #############################################################################################################################
    def resampleResidual(self, w, par):
        H = self.nPart
        H_n = int(H/4)
        Ind = np.empty(H_n, dtype='int')
        num_copies = (np.floor(H_n*np.asarray(w))).astype(int)
        j = 0
        for k in range(H):
            for _ in range(num_copies[k]):  # make n copies
                Ind[j] = k
                j += 1
        residual = w*H_n - num_copies
        residual /= sum(residual)
        csw = np.cumsum(residual)
        csw[-1] = 1
        Ind[j:H_n] = np.searchsorted(csw, np.random.random(H_n-j))
        k= np.repeat(Ind, 10)
        return (k[:self.nPart])

    def kdecomp(self, sys, w, w_b, p_aux, p, tt, w_prev, p_prev, data):
        kern = fit_kde(w, p)
        kern_aux = []
        for i in range(int(sys.par[5])):
            kernt = fit_kde(w_b[:, i], p_aux[:, :, i])
            kern_aux.append(kernt)
        emp_err = 0
        totpdf = 0
        circ = np.array([sys.pl, sys.pl,sys.pl])
        for wt,samp in zip(w,p):
            glist = []
            for kaux in kern_aux:
                if kaux is None:
                    glist.append((0))
                    continue    
                #check the below line, why is pgt always zero, 
                pgt = kaux.integrate_box((samp)-circ, (samp) +circ)
                #print ('pgt', pgt)               
                glist.append((1-pgt))
            emp_err += wt*np.average(glist[:sys.temp_odom])
            totpdf += wt
        emp_err /= totpdf

        # # Plotting
        #need to change the following line for plotting
        if tt % 10 == 10000:
            _thread.start_new_thread(saveDebug, (kern, kern_aux, sys, samp_k))
        kl_prev = comp_KL(w, p, w_prev, p_prev)
        print(tt)
        z = None
        # compute error prob
        gt = sys.true[tt, :]
        gt_p = kern.integrate_box((gt)-circ, (gt) +circ)
        print ('gtp', gt_p)
        return z, emp_err, kl_prev, 1-gt_p



#############################################################################################################################
# End of file
#############################################################################################################################
