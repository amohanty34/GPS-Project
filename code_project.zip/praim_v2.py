from classes import *
from helpers import *
from snapshot import *
import pandas as pd 
import numpy as np
import matplotlib
matplotlib.use('Agg') # no UI backend
import matplotlib.pyplot as plt
from smc import smcSampler
from IPython import display
import os,sys
import time
import pickle
from scipy.signal import savgol_filter
import csv

data = stData()

#change the dir names below
op_dir = "RESULTS/OUT_PFSF"
dbg_dir = "RESULTS/Debug"

if not os.path.exists(op_dir):
    os.makedirs(op_dir)
if not os.path.exists(dbg_dir):
    os.makedirs(dbg_dir)

gtonly           = False;
gen_plots        = True;
snapshot         = False;
num_runs         = 10; #number of runs
num_gnss         = 19; #number of pseudorange measurements 
sys              = stSystemLGSS(num_gnss)
par              = stParameters();
sys.version      = "standard"
lda              = 0.2
sys.par          = np.zeros((8,1))
sys.par[0]       = 1; #autoregressive term
sys.par[1]       = 1e-5; #ground truth motion randomness, 1e-5 original
sys.par[2]       = 1; #0.01; #measuement noise variance- 10, maybe make this 25

sys.par[3]       = 1;    #1e-4#odometry noise-1

sys.par[4]       = 100; #bias noise-100, fault added to the pseudo range

sys.par[5]       = 20; #seems to be an imp parameternumber of odometries for empirical risk, 10 originally

sys.par[6]       = 1; #10**(-13)#logwt gamma scaling

sys.par[7]       = 5; #integrity compute interval 10 originally

sys.bias_p       = 0.8; #bias probability
sys.num_gnss     = num_gnss; #number of pseudorange measurements
sys.num_cam      = 2; #no. of camera measurements btwn 2 pseudorange measurements

sys.T            = 60 #set to 400 originally

sys.pl           = 10; #this is the alert limit, might need to change this to a low no.

sys.dbg_dir      = dbg_dir;
sys.temp_odom    = 10;
sys.num_faults   = 9; #3 originally

file= 'camera_train.xlsx'
df = pd.read_excel(file, usecols="A:H")
#indices need to change na
X= df['X']
X= X[0:sys.T*num_gnss:num_gnss]
Y= df['Y']
Y= Y[0:sys.T*num_gnss:num_gnss]
Z= df['Z']
Z= Z[0:sys.T*num_gnss:num_gnss]
sys.true= np.zeros((sys.T,3))
sys.true[:,0]= X
sys.true[:,1]= Y
sys.true[:,2]= Z  


#construct u from available odometry values
f = 'final_ranges2.xlsx'
df2 = pd.read_excel(f, usecols="A:H")
vel= df2['Vel']
vel= vel[0:sys.T*num_gnss:num_gnss]
#assume x,y,z all have the same velocity if not put only in x
u = np.zeros((sys.T,3))
u[:,0] = vel
u[:,1] = vel
u[:,2] = vel
data.sample(sys,u)

fig, ax = plt.subplots()
timestr = time.strftime("%Y%m%d-%H%M%S")

if(snapshot==True):
    ssol = Snapshotsolver()
    ssol.raim(data,sys,par,ax)
elif(gtonly):
    pass
else:
    sys.par[1] = 5#propagation noise variance
    sm = smcSampler()
    sm.bPF(data,sys,par,ax)
    t = np.linspace(1,sys.T,len(sm.integ))
    t2 = np.linspace(1,sys.T)
    if sm.mode == "praim":
        emp_risk = sm.integ
        print ('emp_risk', emp_risk)
        epsilon = compute_eps(lda, sm.klinteg, 0.1, sys.temp_odom)
        div_risk = inv_bernoulli_div(emp_risk, epsilon)
        print('div_risk', div_risk)
        tot_risk = emp_risk + div_risk
        print('tot_risk', tot_risk)
        ref_risk = sm.error
        print ('ref risk', ref_risk)
        print ('true', sys.true)
        print('estimate', sm.xhatf)
        m_err = np.linalg.norm(np.subtract(sys.true,sm.xhatf), ord=2, axis=1)
        fail_rat = np.sum(ref_risk>tot_risk)/len(tot_risk)*100
        bound_gap = np.average(np.abs(tot_risk-ref_risk))
        csv_data = [fail_rat, np.average(m_err), np.average(m_err[t[ref_risk>tot_risk].astype(int) - 1]), bound_gap]
        print("Fail ratio: ", csv_data[0])
        print("Mean err: ", csv_data[1])
        print("Fail err: ", csv_data[2])
        print("Bound gap: ", csv_data[3])
        with open(r'metrics.csv','a') as f:
            writer = csv.writer(f)
            writer.writerow(csv_data)
        if(gen_plots):
            plt.ylim(0,1)
            plt.legend(labels=['Empirical risk', 'Divergence risk', 'Reference pHMI','Integrity risk bound'])
            plt.plot(t,emp_risk, color='r')
            plt.plot(t,div_risk, color='m')
            plt.plot(t,ref_risk, color='c')
            plt.plot(t,tot_risk, color='k')
            plt.savefig(os.path.join(op_dir, timestr+"_integ1.png"))
    

if(gen_plots or gtonly):
    plt.clf()
    plt.scatter(sys.true[:,0],sys.true[:,1],color='c')   


    if(snapshot==True):
        ssol.xhat = np.array(ssol.xhat)
        print ('ssol',ssol.xhat)
        print ('truesol', sys.true)
        m_err = np.linalg.norm(np.subtract(sys.true,ssol.xhat),ord=2,axis=1)
        print("Mean err:", np.average(m_err))
        plt.scatter(ssol.xhat[:,0],ssol.xhat[:,1],color='k')
        
    elif(gtonly):
        pass
    else:
        #pass
        sm.plotTrajectories(sys)

    plt.savefig(os.path.join(op_dir, timestr+"_path.png"))

