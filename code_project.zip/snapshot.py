import logging
import seaborn as sns
import _thread
import numpy as np
from helpers import *
import matplotlib.pyplot as plt
import matplotlib
import itertools
from scipy import stats
from scipy.optimize import minimize
from IPython import display
import math
import itertools 
pi = math.pi
sns.set(color_codes=True)

class Snapshotsolver(object):
    xhat = []
    def raim(self, data, sys, par, fig):
        num_gnss= sys.num_gnss
        for tt in range(0, sys.T):
            print ('tt', tt)
            x0 = [4051761.737, 617191.1274, 4870822]
            #x0= [0,0,0]
            lsf = lambda x: sys.g(x, [0,0,0], [0,0,0],tt) - data.y[tt]
            pos = [0,0,0]
            min_fun= 1000
            for i in range(19):
                sel = np.ones(19)
                sel[i] = 0
                new_lsf = lambda x: np.linalg.norm(lsf(x)*sel)
                res = minimize(new_lsf, x0, method='nelder-mead', options={'xtol': 1e-8, 'disp': False})
                print ('resfun', res.fun)
                if min_fun> res.fun:
                    pos = res.x
                    min_fun= res.fun
                
            self.xhat.append(list(pos))
