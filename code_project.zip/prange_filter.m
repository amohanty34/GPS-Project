clear;clc;close all;
[nums,~,raw]= xlsread('final_ranges.xlsx');
time= nums(:,1);
tuq= unique(time);
%no corresponds to how many pseudo range meas we want to keep
%mention all this in the report also how hard everything was
n=19;
%if less than this no then discard that time only
indv=[];
for i=1: length(tuq)
    ind= find(time==tuq(i));
    if length(ind)>=n
    indv=[indv ind(1:n)];
    end
end
raw= [raw(1,:);raw(indv+1,:)];
fname= 'final_ranges2.xlsx';
xlswrite(fname,raw);