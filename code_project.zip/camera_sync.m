clc;clear;close all;
%construction of training dataset
%read gnss measurements for imu data
[nums,~,~]= xlsread('prange_data.xlsx');

%extract time from second col
gps_time= nums(:,2);
vel= nums(:,7);
acc= nums(:,6);
lat= nums(:, 4);
long= nums(:,3);
ht= nums(:,5);

[nums2, ~, raw]= xlsread('GuppyRear.csv');
ctime = nums2(:, 2);
names= raw(:,4);names(1)=[];

%get unique gps times
[gpst ind]= unique(gps_time);
vel= vel(ind);
acc= acc(ind);
ht= ht(ind);
lat= lat(ind);
long= long(ind);

%convert lla to ECEF x,y,z
for i=1: length(ht)
    [x(i),y(i),z(i)]= lla_to_ecef(deg2rad(lat(i)), deg2rad(long(i)), ht(i));  
end

%filter out camera times
% indc= find(ctime> gpst(end) | ctime< gpst(1));
% ctime(indc)=[];
% names(indc)=[];


%propagate with imu
csx=[]; csy=[]; csz=[]; cst=[]; ntt=[];
for i= 1: length(gpst)-1
    %extract camera time interval
    ind= find (ctime> gpst(i) & ctime< gpst(i+1));
    camf= ctime(ind);
    namc= names(ind);
    for k=1 : length(camf)
        if k ==1
            dt= camf(1)- gpst(i);
        else
            dt= camf(k)- camf(k-1);   
        end
        xc(k)= imu_forward(x(i), vel(i),acc(i),dt);
        yc(k)= imu_forward(y(i), vel(i),acc(i),dt);
        zc(k)= imu_forward(z(i), vel(i),acc(i),dt); 
        gt(k)= gpst(i);
        nt(k)= namc(k);
    end
    csx=[csx xc];
    csy= [csy yc];
    csz= [csz zc];
    cst= [cst gt];  
    ntt= [ntt nt];
end

%write camera x,y,z and picture name to an excel file
%also append gps times 
header=[{'Name'} {'X'} {'Y'} {'Z'} {'GPStime'}];
X=[ntt',num2cell(csx'),num2cell(csy'),num2cell(csz'), num2cell(cst')];
arr= [header;X];
fname= 'camera_data.xlsx';
xlswrite(fname, arr);


%construction of testing dataset




